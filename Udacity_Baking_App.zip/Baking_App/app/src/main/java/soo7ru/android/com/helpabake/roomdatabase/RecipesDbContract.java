package soo7ru.android.com.helpabake.roomdatabase;

class RecipesDbContract {


    public static final String DATABASE_NAME = "recipes_database";

    public static final String RECIPE_TABLE_NAME = "recipe";
    public static final String INGREDIENT_TABLE_NAME = "ingredient";
    public static final String RECIPESTEP_TABLE_NAME = "recipestep";

}
